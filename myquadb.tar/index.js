import {Component} from 'react'

import Cookies from 'js-cookie'

import Popup from 'reactjs-popup'

import 'reactjs-popup/dist/index.css'

import './index.css'

class SummaryData extends Component {
  state = {sData: {}, seats: 1, name: ''}

  componentDidMount() {
    this.getSummary()
  }

  getSummary = async () => {
    const {match} = this.props
    console.log(match)
    const {params} = match
    const {id} = params
    const response = await fetch(`https://api.tvmaze.com/shows/${id}`)
    console.log(response)
    const data = await response.json()
    console.log(data)
    const updatedData = {
      summary: data.summary,
      officialSite: data.officialSite,
    }
    this.setState({sData: updatedData})
  }

  changeSeats = event => {
    this.setState({seats: event.target.value})
  }

  nameChange = event => {
    this.setState({name: event.target.value})
  }

  storeButton = () => {
    const {name, seats} = this.state
    Cookies.set('no_of_seats', {name, seats}, {expires: 30})
  }

  render() {
    const {sData, seats} = this.state
    console.log(seats)
    return (
      <div className="my-conatiner">
        <h1 className="heading2">Summary of the movie</h1>
        <div className="product-item-details-container">
          <p className="product-name">{sData.summary}</p>
          <div className="visit-container">
            <a href={sData.officialSite}>Visit</a>
            <Popup
              modal
              className="popup-content"
              trigger={
                <button type="button" className="trigger-button">
                  Book Now
                </button>
              }
            >
              {close => (
                <>
                  <div>
                    <h2>Book Movie Ticket</h2>
                    <p>Select your preferences and confirm the booking.</p>
                    <input
                      placeholder="Enter Your Name"
                      onChange={this.nameChange}
                    />
                    <label>
                      Number of Seats:
                      <select onChange={this.changeSeats} value={seats}>
                        <option value={1}>1</option>
                        <option value={2}>2</option>
                        <option value={3}>3</option>
                        <option value={4}>4</option>
                        <option value={5}>5</option>
                      </select>
                    </label>
                    <button
                      type="button"
                      className="trigger-button"
                      onClick={() => close()}
                    >
                      Close
                    </button>
                    <Popup
                      position="top center"
                      trigger={
                        <button
                          type="button"
                          className="trigger-button trigger2"
                          onClick={this.storeButton}
                        >
                          confirm
                        </button>
                      }
                    >
                      <div>
                        <h1 className="heading5">
                          Congratulation you booked {seats} tickets
                        </h1>
                      </div>
                    </Popup>
                  </div>
                </>
              )}
            </Popup>
          </div>
        </div>
      </div>
    )
  }
}

export default SummaryData
